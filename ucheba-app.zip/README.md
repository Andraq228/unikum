# Учёба

Учебное приложение для Windows и Android: дедлайны, фото-калькулятор, рефераты и слайды, ИИ-чат.

Каждый пользователь вводит свои ключи в разделе «Ключи»:
- OpenRouter — https://openrouter.ai/keys (основной ИИ, есть бесплатные модели)
- Google Gemini — https://aistudio.google.com/apikey (запасной ИИ)
- PDF.co — https://app.pdf.co (необязательно, для PDF-файлов)

Ключи, дедлайны и история хранятся только на устройстве пользователя.

Сборка: вкладка Actions → последний запуск → Artifacts (Ucheba-Windows, Ucheba-Android).
